"""Fresh V1 Double DQN run. Reproduces the method, not an identical GPU trajectory.

Put this file beside the V1 game modules. Run in a fresh Python process:
python train_from_scratch.py --model B --steps 300000
python train_from_scratch.py --model C --steps 300000
Each run creates a new folder; existing results are never overwritten.
"""
import argparse
import hashlib
import json
import random
import time
from collections import deque
from datetime import datetime,timezone
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
from torch import nn
import gym_env
from night_env import GoalShaping


class DQN(nn.Module):
    def __init__(self,hidden_sizes):
        super().__init__()
        layers=[]
        previous=60
        for size in hidden_sizes:
            layers.extend([nn.Linear(previous,size),nn.ReLU()])
            previous=size
        layers.append(nn.Linear(previous,15))
        self.layers=nn.Sequential(*layers)

    def forward(self,x):
        return self.layers(x)


def write_json(path,data):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')
    temporary.replace(path)


def save_weights(path,model):
    temporary=path.with_suffix('.tmp')
    torch.save({key:value.detach().cpu() for key,value in model.state_dict().items()},temporary)
    temporary.replace(path)


def train(model_name,steps,output=None):
    if model_name not in ('B','C'):
        raise ValueError('Choose model B or C')
    if steps<1:
        raise ValueError('steps must be positive')
    here=Path(__file__).resolve().parent
    if gym_env.ENV_ID!='NightShift-v0' or Path(gym_env.__file__).resolve()!=here/'gym_env.py':
        raise RuntimeError('Use a fresh Python process and the V1 modules beside this script.')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    folder=Path(output) if output else Path.cwd()/'reproduction_runs'/f'{model_name}_{stamp}'
    folder.mkdir(parents=True,exist_ok=False)
    config={'model':model_name,'algorithm':'DoubleDQN','env_id':'NightShift-v0',
        'hidden_sizes':[64,64] if model_name=='B' else [128,128,64],
        'seed':42,'gamma':0.995,'learning_rate':0.0001,'batch_size':64,
        'memory_capacity':50000,'warmup_steps':2000,'train_every':4,'target_update':1000,
        'epsilon_start':1.0,'epsilon_end':0.1,'epsilon_decay_steps':100000,
        'reward_mode':'potential','potential_scale':8.0,'target_steps':steps}
    random.seed(config['seed'])
    np.random.seed(config['seed'])
    torch.manual_seed(config['seed'])
    torch.set_num_threads(1)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    env=GoalShaping(gym.make('NightShift-v0'),scale=8.0,gamma=config['gamma'])
    observation,info=env.reset(seed=config['seed'])
    policy=DQN(config['hidden_sizes']).to(device)
    target=DQN(config['hidden_sizes']).to(device)
    target.load_state_dict(policy.state_dict())
    target.eval()
    optimizer=torch.optim.Adam(policy.parameters(),lr=config['learning_rate'])
    memory=deque(maxlen=config['memory_capacity'])
    episodes=[]
    losses=[]
    completed=0
    episode_reward=base_reward=0.0
    episode_steps=0
    status='running'
    started=time.perf_counter()
    sources={name:hashlib.sha256((here/name).read_bytes()).hexdigest() for name in
             ['gym_env.py','simulation.py','handling.py','pursuit.py','night_env.py']}
    write_json(folder/'config.json',{'config':config,'device':str(device),
        'torch_version':torch.__version__,'numpy_version':np.__version__,'source_hashes':sources,
        'note':'Fresh method reproduction. Weights and history are saved; this is not a full resumable checkpoint.'})

    def save():
        save_weights(folder/'weights.pt',policy)
        if completed and completed%50000==0:
            save_weights(folder/f'weights_{completed:07d}.pt',policy)
        write_json(folder/'history.json',{'episodes':episodes,'losses':losses})
        write_json(folder/'status.json',{'status':status,'completed_steps':completed,'target_steps':steps,
            'training_seconds':time.perf_counter()-started,'partial_episode_steps':episode_steps})

    print(f'{model_name}: fresh V1 run on {device}; {steps:,} steps; output {folder}',flush=True)
    try:
        for previous_step in range(steps):
            fraction=min(1.0,previous_step/config['epsilon_decay_steps'])
            epsilon=1.0+(.1-1.0)*fraction
            if random.random()<epsilon:
                action=random.randrange(15)
            else:
                with torch.no_grad():
                    x=torch.as_tensor(observation,dtype=torch.float32,device=device).unsqueeze(0)
                    action=int(policy(x).argmax(1).item())
            next_observation,reward,terminated,truncated,info=env.step(action)
            # Only genuine termination removes the bootstrap value.
            memory.append((observation,action,reward,next_observation,terminated))
            observation=next_observation
            episode_reward+=reward
            base_reward+=info['base_reward']
            episode_steps+=1
            step=previous_step+1
            if step>=config['warmup_steps'] and step%config['train_every']==0:
                batch=random.sample(list(memory),config['batch_size'])
                states,actions,rewards,next_states,terminals=zip(*batch)
                states=torch.as_tensor(np.array(states),dtype=torch.float32,device=device)
                actions=torch.tensor(actions,dtype=torch.long,device=device)
                rewards=torch.tensor(rewards,dtype=torch.float32,device=device)
                next_states=torch.as_tensor(np.array(next_states),dtype=torch.float32,device=device)
                terminals=torch.tensor(terminals,dtype=torch.float32,device=device)
                predicted=policy(states).gather(1,actions[:,None]).squeeze(1)
                with torch.no_grad():
                    # Online network chooses; target network evaluates.
                    next_actions=policy(next_states).argmax(1,keepdim=True)
                    next_q=target(next_states).gather(1,next_actions).squeeze(1)
                    expected=rewards+config['gamma']*(1-terminals)*next_q
                loss=nn.functional.smooth_l1_loss(predicted,expected)
                if not torch.isfinite(loss):
                    raise FloatingPointError('Non-finite training loss')
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(policy.parameters(),10)
                optimizer.step()
                losses.append({'step':step,'loss':float(loss.item())})
            if step%config['target_update']==0:
                target.load_state_dict(policy.state_dict())
            if terminated or truncated:
                episodes.append({'step':step,'reward':episode_reward,'base_reward':base_reward,
                    'steps':episode_steps,'seconds':info['elapsed'],'success':bool(info['success']),
                    'health':info['health']})
                observation,info=env.reset()
                episode_reward=base_reward=0.0
                episode_steps=0
            completed=step
            if step%10000==0:
                save()
                print(f'{step:,}/{steps:,} | epsilon {epsilon:.3f} | episodes {len(episodes)}',flush=True)
        status='complete'
    except KeyboardInterrupt:
        status='interrupted'
        print('Interrupted. Saving current weights and completed-episode history.',flush=True)
    except Exception:
        status='error'
        raise
    finally:
        save()
        env.close()
    print(f'{model_name}: {status}; {completed:,} completed steps; saved {folder}',flush=True)
    return folder


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=['B','C'],required=True)
    parser.add_argument('--steps',type=int,default=300000)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    train(args.model,args.steps,args.output)
